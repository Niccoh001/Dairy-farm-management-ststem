from django.apps import AppConfig


class FinancialManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'financial_management'
